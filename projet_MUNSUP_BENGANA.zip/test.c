#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main(){
    int x;
    printf("veillez choisir la valeur 1,2,3, x = ");
    scanf("%d",&x );
    printf("x = %d \n",x);
}